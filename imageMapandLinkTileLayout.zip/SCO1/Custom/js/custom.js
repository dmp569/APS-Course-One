/**************************************************************************
** NOTE TO COURSE DEVELOPERS:
** -- Any custom JavaScript should be placed in this file.
** -- Changes to course.js or other code provided as part of
**    this SDK is strictly prohibited.
** -- JavaScript in content .htm files should be limited to event handlers
**   (e.g. onClick, onMouseEnter, etc.) which call functions in this file.
** -- No custom JavaScript script blocks should be in content .htm files.
**************************************************************************/
