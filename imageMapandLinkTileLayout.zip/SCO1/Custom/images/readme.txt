To include a custom thumbnail image in Infopedia (MyLearning), place a 315x177 JPG file in the Custom/images folder. APS will upload it when you publish.

The file must be named "aps-315x177.jpg" and be those dimensions to work correctly in Infopedia. The name is standard across all courses and not customized for each course. 

The standard image has been renamed so that it will not automatically be uploaded per request of the IP team.